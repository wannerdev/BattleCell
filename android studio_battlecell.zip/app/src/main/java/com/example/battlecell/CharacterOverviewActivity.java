package com.example.battlecell;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class CharacterOverviewActivity extends Activity {
	@Override
    protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//show the xml file
		Data database = Data.getInstance(this.getApplicationContext());
		setContentView(R.layout.activity_character);
		//check if a database is existing
		if(database != null){
			Character me = database.getCharacter(0);
			TextView t;
			t =(TextView) this.findViewById(R.id.name);
			t.setText(me.getName());
			

			//goActivity.putExtra("experience", String.valueOf((me.getLevel()%1000)) );
			//doesn't make sense :o
			t =(TextView) this.findViewById(R.id.experience);
			t.setText(String.valueOf(me.getExperience()) );
			
			t =(TextView) this.findViewById(R.id.level);
			t.setText(String.valueOf(me.getLevel()) );
	
			t =(TextView) this.findViewById(R.id.attribute);
			t.setText(String.valueOf(me.getAttribute()) );
	
			t =(TextView) this.findViewById(R.id.victories);
			t.setText(String.valueOf(me.getVictories()) );
	        
			t =(TextView) this.findViewById(R.id.losses);
			t.setText(String.valueOf(me.getLosses()) );
		}
        database.close();
       
    }
	
	@Override
	public void onBackPressed() {
		this.finish();
		return;
   }
}
