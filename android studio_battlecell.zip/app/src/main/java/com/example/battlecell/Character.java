package com.example.battlecell;

import android.util.Log;

public class Character {



	private String name;
	private int attribute = 0;
	private int losses = 0;
	private int level = 0;
	private double experience = 0;
	private int victories = 0, lastdice_guy = 0, lastdice_me = 0;
	private static int counter = 0;
	private int id;
	boolean russianroulett = false, generated = false;
	


	Character(String name_, int attribute1, int losses_, int victories_, int level_,double experience_){
		try{
			setExperience(experience_);
			setLevel(level_);
			setName(name_);
			setAttribute( attribute1);
			setLosses( losses_);
			setVictories(victories_);
		}catch(Exception e){
			Log.d("Character", e.getLocalizedMessage());
		}
		counter = counter++;
		id = counter;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) throws Exception {
		if( name != null || name == "") {
			this.name = name;
		}else{
			throw new Exception("name null");
		}
	}

	public int getAttribute() {
		return attribute;
	}

	public void setAttribute(int attribute) throws Exception {
		if(attribute > 0){
			this.attribute = attribute;
		}else{
			throw new Exception("not valid attribute");
		}
	}

	public int getLosses() {
		return losses;
	}

	private void setLosses(int losses) throws Exception {
		if(losses >= 0){
			this.losses = losses;
		}else{
			throw new Exception("not valid losses");
		}
	}

	public int getVictories() {
		return victories;
	}

	private void setVictories(int victories) throws Exception {
		if(victories >= 0){
			this.victories = victories;
		}else{
			throw new Exception("not valid victories");
		}
		
	}


	public int getId() {
		return id;
	}
		
	public int getLastdice_guy() {
		return lastdice_guy;
	}


	private void setLastdice_guy(int lastdice_guy) throws Exception {
		if(lastdice_guy <= 0)throw new Exception("diceg wrong");
		this.lastdice_guy = lastdice_guy;
	}


	public int getLastdice_me() {
		return lastdice_me;
	}


	private void setLastdice_me(int lastdice_me) throws Exception {
		if(lastdice_me <= 0)throw new Exception("dicem wrong");
		this.lastdice_me = lastdice_me;
	}
	
	private void setLevel(int level) throws Exception {
		if(level < 0) throw new Exception("level invalid"+ this.getName());
		Log.d("lvl set", String.valueOf(level)+this.name );
		this.level = level;
	}
	
	public int getLevel() {
		return level;
	}
	
	public void setExperience(double experience_) throws Exception {
		if(experience < 0) throw new Exception("experience invalid"+ this.getName());
		experience = experience  + experience_;
		if(experience >1000){
			setLevel(level+1);
			experience = experience %1000;
		}
	}

	public double getExperience() {
		return experience;
	}


	
	public void increaseAttribute(){
		attribute++;
	}
	public boolean isrussianroulett(){
		return russianroulett;
	}
	
	public boolean isGenerated() {
		return generated;
	}


	public void setGenerated(boolean generated) {
		this.generated = generated;
	}
	
	@Override
	public String toString() {
		return "Character [name=" + name + ", attribute=" + attribute
				+ ", losses=" + losses + ", level=" + level + ", experience="
				+ experience + ", victories=" + victories + ", lastdice_guy="
				+ lastdice_guy + ", lastdice_me=" + lastdice_me + ", id=" + id
				+ ", russianroulett=" + russianroulett + ", generated="
				+ generated + "]";
	}

	private void increaseVictories(Character guy) throws Exception {
		//The higher the level the less experience you get for a win depending on the enemies level
		this.setExperience( (  1/Double.valueOf(getLevel())  * ((Double.valueOf(guy.getLevel())*0.5) * 400) ) );
		Log.v(String.valueOf(1/getLevel()  * ((guy.getLevel()*0.5) * 400) ), "show xp");
		victories++;
		
		
	}
	
	private void increaseLosses(Character guy) throws Exception {
		//The higher the level the less experience you get for a win depending on the enemies level
		//The player gets as much experience as if he was 2 levels higher so less experience
		this.setExperience(( (1/(getLevel() + 2.0)) * ((guy.getLevel()*0.5) * 200) ) ); //
		losses++;
		
	}
	
	public boolean fight(Character guy){
		boolean result = false;
		try{
			if(guy.getLevel() <= 0)throw new Exception("guys level invalid");
			if(guy.getAttribute() > this.getAttribute()){
				guy.increaseVictories(guy);
				this.increaseLosses(guy);
			}else if(guy.getAttribute() < this.getAttribute()){
				this.increaseVictories(guy);
				guy.increaseLosses(guy);
				result = true;
			}else{
				russianroulett = true;
				setLastdice_guy( guy.dice() );
				setLastdice_me( this.dice());
				if(lastdice_guy > lastdice_me){
					guy.increaseVictories(guy);
					this.increaseLosses(guy);
				}else{ //equal 
					result = true;
					this.increaseVictories(guy);
					guy.increaseLosses(guy);
				}
			}
		}catch(Exception e){
			Log.e("fight", "should be setlevel  " +e.getLocalizedMessage());
		}
		return result;
	}

	public int dice(){
		return (int)( 1+ (Math.random()*6));
	}







}
