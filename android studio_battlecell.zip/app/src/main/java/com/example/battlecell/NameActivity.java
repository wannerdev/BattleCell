package com.example.battlecell;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class NameActivity extends Activity{
	EditText mEdit;
	Button mButton;
	String name = "something went wrong";
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //super.onStart();
        this.getIntent().getStringExtra(name);
        setContentView(R.layout.activity_name);
        if(findViewById(R.id.editText1) instanceof EditText){
        	mEdit = (EditText) findViewById(R.id.editText1);
        }else{
        	Log.e("WTF", "widgets are not what they seem to be");
        }
        
        if(findViewById(R.id.Button01) instanceof Button){
        	mButton = (Button) findViewById(R.id.Button01);
        }else{
        	Log.e("WTF", "widgets are not what they seem to be");
        }
        
        mButton.setOnClickListener(
        		new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							Log.v("edittex", mEdit.getText().toString());
							name = mEdit.getText().toString();
							Intent goActivitymain = new Intent(getApplicationContext(), MainActivity.class);
							goActivitymain.putExtra("name", name);
							startActivity(goActivitymain);
							//
							finish();
						}
        		});
        
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
