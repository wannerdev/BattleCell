package com.example.battlecell;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class BattleActivity extends Activity {

	@Override
    protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        setContentView(new BattleView(this));
       
    }
	
	protected void gameOver(int won,BattleLoop lo){
		lo.setRunning(false);
        Intent goActivity = new Intent(getApplicationContext(), TrainingActivity.class);
		goActivity.putExtra("gameover", won);
		setResult(Activity.RESULT_OK ,goActivity);
        //startActivity(goActivity);
		this.finish();

		Log.v("gameOver","end");
	}
}
