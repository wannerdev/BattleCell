package com.example.battlecell;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;

public class BattleView extends SurfaceView {
	
	private SurfaceHolder surfaceHolder;
	private Bitmap bmp;
	private BattleActivity battleactivity;
	private BattleLoop battleLoop;
	private long lastClick;
	private int y = 0, x = 0, height = 0, width = 0, or_height = 0, or_width = 0, speed = 2;
	private int counter = 0, timeframe = 25;
	private char direction = 'd';
	private boolean once = true, shall = true;
	
	public BattleView(Context context) {
		super(context);
		battleactivity = (BattleActivity) context;
        battleLoop = new BattleLoop(this);
        Toast.makeText(context, "Catch the bug to win", Toast.LENGTH_LONG).show();
    	
        surfaceHolder = getHolder();
        surfaceHolder.addCallback(new SurfaceHolder.Callback() {
 
            public void surfaceDestroyed(SurfaceHolder holder) {
            	boolean retry = true;
            	battleLoop.setRunning(false);
                while(retry){
                    try {
                    	battleLoop.join();
                        retry = false;
                    }catch(InterruptedException e){
 
                    }
                }
            }
 
            public void surfaceCreated(SurfaceHolder holder) {
            	battleLoop.setRunning(true);
                battleLoop.start();
            }
 
            public void surfaceChanged(SurfaceHolder holder, int format,
                    int width, int height) {
 
            }
        });
        bmp = BitmapFactory.decodeResource(getResources(), R.drawable.bug_icon);
       
	}
	@SuppressLint("DrawAllocation")
	@Override
	protected void onDraw(Canvas canvas) {
		if(canvas != null){
	     canvas.drawColor(Color.DKGRAY);
	     if(once){
	    	 or_height = getHeight()-bmp.getHeight();
	    	 or_width = getWidth()-bmp.getWidth();
	    	 width = or_width;//(int) Math.random() * or_width;
	    	 height = or_height;//(int) Math.random() * or_height;
    		//speed and paddings according to screen sizes
	    	 speed = or_height*or_width/200000; //tested with oneplus one specs
	    	 //TODO
	    	 //speed = or_height*or_width/200000 * (lvl/10); get character and his lvl
		       
	    	 double random =  Math.random() * 100;
	    	 //x = (int) (Math.random() * or_width);
	    	 //y= (int) (Math.random() * or_height);
	    	 
	    	 if(random <= 25.0){
	    		 //lower right corner
		    	 x =  or_width;
		    	 y =  or_height;//(int) Math.random() * or_height; 
		    	 direction = 'u';
	    	 }else if(random <= 50.0){
	    		 //upper left corner
		    	 x = 0;//(int) Math.random() * or_width;
		    	 y = 0;//(int) Math.random() * or_height;
	    		 
	    	 }else if(random <= 75.0){
		    	 //lower left corner
	    		 x = 0;//(int) Math.random() * or_width;
		    	 y = or_height;//(int) Math.random() * or_height;
		    	 direction = 'r';
	    		 
	    	 }else if(random <= 100.0){
	    		 //upper right corner
		    	 x = or_width;//(int) Math.random() * or_width;
		    	 y = 0;//(int) Math.random() * or_height;
		    	 direction = 'l';
	    		 
	    	 }else{
		    	 width = or_width;//(int) Math.random() * or_width;
		    	 height = or_height;//(int) Math.random() * or_height;
	    		 
	    	 }
	    	 once = false;
	     }
	     //in which direction the bug crawls
	     switch(direction){
	     		//simple check if coordinates would extend the screen before assignment 
	     		case 'd':
	     			//down
	     			y = (y+speed >height) ?  height : y+speed;
	     			break;
	     		case 'r':
	     			//right
	     			//
	     			x =  (x+speed >width) ? width :x+speed;
	     			break;
	     		case 'u':
	     			//up
	     			//y = y-speed;
	     			y = (y-speed < (or_height - height) ) ?  (or_height - height) : y-speed;
	     			break;
	     		case 'l':
	     			//left
	     			//x = x-speed
	     			//Log.v("battleview", "x:"+String.valueOf(x-speed)+" < "+String.valueOf( or_width - width));
	     		     ;
	     			x = (x-speed < or_width - (width-20)) ? or_width - (width-20) : x-speed;
	     			break;
	     }
	     //Log.v("battleview", "x:"+String.valueOf(x)+" und y:"+String.valueOf(y) + " height"+String.valueOf(height)+" width:"+String.valueOf(width));
	     
	     //change route to increase difficulties
	     if(y == height && x == (or_width - width)){// && direction != 'r'){
	    	 Log.v("battleview", "right");
	    	 //if on  bottom left change direction to right
	    	 //y=getHeight()-20;
	    	 direction = 'r';
	     }else if(x == width && y == height){// && direction != 'u'){
	    	 Log.v("battleview", "up");	    	 
	    	 //if on the bottom right go up
	    	 //x = getWidth();
	    	 direction='u';
	     }else if(x == width && y == (or_height - height)){// && direction != 'l'){
	    	 Log.v("battleview", "left");
	    	 //if on top right go left
	    	 direction = 'l';
		}else if(x <= (20 + or_width - width ) && y == (or_height - height)){//&& direction != 'd'){
	    	 Log.v("battleview", "down");
	    	 //if top left go down
	    	 direction = 'd';
	    	 //adjust = adjust / 10;
	    	 width = width - 20;
	    	 height = height - 20;
	    	 if(width <= (or_width/2) || height <= (or_height/2)){
		    	 Log.v("battleviewwidth", "in");
		    	 battleactivity.gameOver(0,battleLoop);
		        	
		        	
			 }
		}
	    counter++;
	    if(counter == 10 || counter == 20)timeframe = timeframe -5;
	    if( counter ==  timeframe ){
	    	counter = 0;
	    	shall = !shall;
	    }
	    if(shall){
	    	canvas.drawBitmap(bmp, x, y, null);
	    }
	    
	    /*
	    if(x > width) {
	    	Log.v("battleviewwidth", "in");
	    	
        	battleactivity.gameOver(0,battleLoop);
        	//battleloop.
        	
        	
	    }*/
		}
	}
	
	@SuppressLint("WrongCall")
	@Override
	public synchronized boolean onTouchEvent(MotionEvent event) {
	    boolean result = false;
	    float x2 = event.getX();
	    float y2 = event.getY();
		if (System.nanoTime()  - lastClick > 300) {
	        lastClick = System.nanoTime() ;
	        Canvas can =  getHolder().lockCanvas();
	       // Canvas.
	       // this.g
	        synchronized (can) {
	        	//did he catch the bug?
		        if(x2 > x && x2 < x + bmp.getWidth() && y2 > y && y2 < y + bmp.getHeight()){
		        	//draw the splash
		        	bmp = BitmapFactory.decodeResource(getResources(), R.drawable.splash);
		        	Sprite splash = new Sprite( x, y, bmp,this);
		       		splash.onDraw(can);
		        	result = true;
		        	battleactivity.gameOver(1,battleLoop);
		        	//battleLoop.setRunning(false);
		        	
		        }
	        }
	        getHolder().unlockCanvasAndPost(can);
		}
	    return result;
	}


}
