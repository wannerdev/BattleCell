package com.example.battlecell;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.View;

public class Sprite {

	private int xpos, ypos;
	private int width,height;
	private Bitmap bmp;
	private View gameview;
	

	public Sprite(int xpos, int ypos, Bitmap bmp, View gameview) {
		super();
		this.xpos = xpos;
		this.ypos = ypos;
		this.width = bmp.getWidth();
		this.height = bmp.getHeight();
		this.bmp = bmp;
		this.gameview = gameview;
	}

	public int getXpos() {
		return xpos;
	}

	public void setXpos(int xpos) {
		this.xpos = xpos;
	}

	public int getYpos() {
		return ypos;
	}

	public void setYpos(int ypos) {
		this.ypos = ypos;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public Bitmap getBmp() {
		return bmp;
	}

	public void setBmp(Bitmap bmp) {
		this.bmp = bmp;
	}

	public View getGameview() {
		return gameview;
	}

	public void setGameview(View gameview) {
		this.gameview = gameview;
	}
	
	public void onDraw(Canvas canvas){
		canvas.drawBitmap(bmp, xpos, ypos, null);
	}
}
