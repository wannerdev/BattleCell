package com.example.battlecell;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {
	private Data database;
	private Button buttonSearch, buttontraining, buttonChar;
	private Character me;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //super.onStart();
        database = Data.getInstance(this);
        
        //On first time executing the app create the character
        if(this.getIntent().getStringExtra("name") !=null ){
        	String name = this.getIntent().getStringExtra("name");
        	Log.v("mainactv", name);
        	me = new Character(name,1,0,0,1,0);
        	database.addCharacter(me);
        	Log.v("intentmain", "works");
        }
        //database.onUpgrade(database, 1, 1);
        Character guy = database.getCharacter(0);
        if( guy  instanceof  Character ) {	
        	me = guy;
        	setContentView(R.layout.activity_main);
        	Log.v("ifmain", "tuut");
        }else{
        	Intent GoActivityname = new Intent(getApplicationContext(), NameActivity.class);
        	this.startActivity(GoActivityname);
        	
        }
    }
    
    @Override
    protected void onStart(){
    	super.onStart();
    	setContentView(R.layout.activity_main);
    	
    	if( database.getCharacter(0) instanceof  Character ){
    		//get ze buttons
	    	buttonSearch = (Button) findViewById(R.id.search);
	    	buttontraining = (Button) findViewById(R.id.battle);
	    	buttonChar = (Button) findViewById(R.id.character);
	        
	    	//Search for other player
	        buttonSearch.setOnClickListener(
	        		new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								Log.v("edittex", "battle Search");
								Intent goActivity = new Intent(getApplicationContext(), SearchActivity.class);
								
								startActivity(goActivity);			
								
							}
	        		});
	        //Training
	        buttontraining.setOnClickListener(
	        		new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								Log.v("edittex", "buttontraining");
								Intent goActivity = new Intent(getApplicationContext(), TrainingActivity.class);
								//goActivitymain.putExtra("name", name);
								//startActivityForResult(goActivity,1);			
								startActivity(goActivity);
							}
	        		});
	        //Character
	        buttonChar.setOnClickListener(
	        		new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								Log.v("edittex", "button character");
								Intent goActivity = new Intent(getApplicationContext(), CharacterOverviewActivity.class);
								
//								goActivity.putExtra("name", me.getName());
//								goActivity.putExtra("level", String.valueOf(me.getLevel()) );
//								goActivity.putExtra("experience", String.valueOf(me.getExperience()) );
//								goActivity.putExtra("attribute", String.valueOf(me.getAttribute()) );
//								goActivity.putExtra("losses", String.valueOf(me.getLosses()) );
//								goActivity.putExtra("victories", String.valueOf(me.getVictories()) );
								startActivity(goActivity);			
								
							}
	        		});
    	}
    }

    
//    @Override
//    public void onBackPressed() {
//        this.
//        return;
//    }
//    @Override
//    public void onActivityResult(int requestCode, int resultCode, Intent data_) {
//      super.onActivityResult(requestCode, resultCode, data_);
//      switch(requestCode) {
//        case (1) : {
//          if (resultCode == Activity.RESULT_OK) {
//        	  Character guy = new Character(data_.getStringExtra("name"),1,0,0);
//        	  database.addCharacter(guy);
//          }
//          break;
//        } 
//      }
//    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
 
    
}
