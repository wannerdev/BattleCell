package com.example.battlecell;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class TrainingActivity extends Activity {


	private Button buttongame1, buttongame2, buttongame3;
	private Character me;
	private Data database;
	
	 @Override
	 protected void onCreate(Bundle savedInstanceState) {
		 super.onCreate(savedInstanceState);
		 setContentView(R.layout.activity_training_games);
		 database = Data.getInstance(this.getApplicationContext());
	 }
	 
	 @Override
	 protected void onStart(){
	    	super.onStart();
	    	me = database.getCharacter(0);
	    	setContentView(R.layout.activity_training_games);
		 	buttongame1 = (Button) findViewById(R.id.Game1);
	    	buttongame2 = (Button) findViewById(R.id.Game2);
	    	//buttongame3 = (Button) findViewById(R.id.Game3);
	        
	    	//
	    	buttongame1.setOnClickListener(
	        		new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								Log.v("buttongame1", "battle ");
								Intent goActivity = new Intent(getApplicationContext(), BattleActivity.class);
								
								startActivityForResult(goActivity,1);			
								
							}
	        		});
	        //
	    	buttongame2.setOnClickListener(
	        		new View.OnClickListener() {
							@Override
							public void onClick(View v) {
								Log.v("buttongame2", "2");
								Intent goActivity = new Intent(getApplicationContext(), Game2Activity.class);
								//goActivitymain.putExtra("name", name);
								startActivityForResult(goActivity,2);			
								
							}
	        		});
	        
//	    	buttongame3.setOnClickListener(
//	        		new View.OnClickListener() {
//							@Override
//							public void onClick(View v) {
//								Log.v("edittex", "button character");
//								Intent goActivity = new Intent(getApplicationContext(), CharacterOverviewActivity.class);
//								startActivityForResult(goActivity,1);	
//							}
//	        		});
	 }
	 
	 @Override
	    public void onActivityResult(int requestCode, int resultCode, Intent data) {
	      super.onActivityResult(requestCode, resultCode, data);
	      switch(requestCode) {
		        case (1) : 
			          if (resultCode == Activity.RESULT_OK) {
			            // Treat game results
			        	  int result=0;
			        	  result = data.getIntExtra("gameover", result);
			        	  AlertDialog.Builder alertbox= new AlertDialog.Builder(this);
			        	  // prepare the alert box
			        	  if(result >0){
			        		  	try {
			        	        	 // set the message to display
			        	        	 alertbox.setMessage("You Won!");
			        	        	 if(me == null)Log.e("main", "me null");
			        	        	 me.increaseAttribute();
			        	 	        database.updateCharacter(me);
			        		  	} catch (Exception e) {
			        		  		//logcats error msg
			        		  		Log.e("training_acti", "hm"+e.getLocalizedMessage());
			        		  	}
			        	  }else{
			   	        	 // set the message to display
			   	        	 alertbox.setMessage("You Lost!");
			        	        	 
			   	         }
			       	    // add a neutral button to the alert box and assign a click listener
			       	    alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() {         
			        	            // click listener on the alert box
			        	            public void onClick(DialogInterface arg0, int arg1) {
			        	                // the button was clicked
			        	                //Toast.makeText(getApplicationContext(), "OK button clicked", Toast.LENGTH_LONG).show();
			        	            	
			        	            }
			        	        });	  
			           // show it
			          	alertbox.show();
			        	}
			          break;
		        case(2): 
			          if (resultCode == Activity.RESULT_OK) {
				            // Treat game results
				        	  long result=0;
				        	  result = data.getLongExtra("gameover", result);
				        	  AlertDialog.Builder alertbox= new AlertDialog.Builder(this);
				        	  // prepare the alert box
				        	  if(result >0){
				        		  	try {
				        	        	 // set the message to display
				        	        	 alertbox.setMessage("You Won!");
				        	        	 if(me == null)Log.e("main", "me null");
				        	        	 while(result > 0){				        	        	 
				        	        		 me.increaseAttribute();
				        	        		 result--;
				        	        	 }
				        	 	        database.updateCharacter(me);
				        		  	} catch (Exception e) {
				        		  		//logcats error msg
				        		  		Log.e("mainact", "hm"+e.getLocalizedMessage());
				        		  	}
				        	  }else{
				   	        	 // set the message to display
				   	        	 alertbox.setMessage("You Lost!");
				        	        	 
				   	         }
				       	    // add a neutral button to the alert box and assign a click listener
				       	    alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() {         
				        	            // click listener on the alert box
				        	            public void onClick(DialogInterface arg0, int arg1) {
				        	                // the button was clicked
				        	                //Toast.makeText(getApplicationContext(), "OK button clicked", Toast.LENGTH_LONG).show();
				        	            	
				        	            }
				        	        });	  
				           // show it
				          	alertbox.show();
			          }
				break;
		       
	      }
	    }
}
