package com.example.battlecell;

import android.app.Activity;
import android.content.Context;
import android.content.IntentFilter;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Johannes Wanner on 26.01.2015.
 */
public class FightRandomActivity extends Activity {

    //random Enemy
    private int leveldepended = 20;
    private int leveldepended2 = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fight_random); //Set the view


        //as long as search is not implemented
        //assume he chose random enemy
        Data database = Data.getInstance(this);
        Character me = database.getCharacter(0);
        if(me != null){
            TextView t;
            //display my statistics
            t =(TextView) this.findViewById(R.id.name_me);
            t.setText(me.getName());

            t =(TextView) this.findViewById(R.id.level_me);
            t.setText(String.valueOf(me.getLevel()));

            t =(TextView) this.findViewById(R.id.attribute_me);
            t.setText(String.valueOf(me.getAttribute()));

            t =(TextView) this.findViewById(R.id.victories_me);
            t.setText(String.valueOf(me.getVictories()));

            t =(TextView) this.findViewById(R.id.losses_me);
            t.setText(String.valueOf(me.getLosses()));

            //generate guy
            try {
                Character guy;
                guy = generateRandomEnemy(me);
                Log.e("grad", "lvl:" + String.valueOf(guy.getLevel()));

                //	if(R.id.attribute_guy == 0)Log.v("search", " "+guy.toString());
                //guys statistics
                t =(TextView) this.findViewById(R.id.name_guy);
                t.setText(guy.getName());

                t =(TextView) this.findViewById(R.id.level_guy);
                t.setText(String.valueOf(guy.getLevel()));

                t =(TextView) this.findViewById(R.id.attribute_guy);
                t.setText(String.valueOf(guy.getAttribute()));

                t =(TextView) this.findViewById(R.id.victories_guy);
                t.setText(String.valueOf(guy.getVictories()));

                t =(TextView) this.findViewById(R.id.losses_guy);
                t.setText(String.valueOf(guy.getLosses()));

                Log.v("search", "fight");
                //Fight!
                boolean won = me.fight(guy);
                int i=0,j=0;
                if(me.isrussianroulett()){
                    Toast.makeText(getApplicationContext(), "Same Power you play russian roulett old school ", Toast.LENGTH_LONG).show();

                    boolean bothalive = true;
                    while(bothalive){

                        Toast.makeText(getApplicationContext(), "He turns a switch", Toast.LENGTH_LONG).show();
                        j++;
                        if(j == me.getLastdice_guy()){
                            //sound?
                            Toast.makeText(getApplicationContext(), "Boom! You win", Toast.LENGTH_LONG).show();
                            bothalive = false;
                        }else{
                            Toast.makeText(getApplicationContext(), "...", Toast.LENGTH_LONG).show();
                        }
                        Toast.makeText(getApplicationContext(), "you turn a switch", Toast.LENGTH_LONG).show();
                        i++;
                        if(i == me.getLastdice_me() && bothalive ){
                            //sound?
                            Toast.makeText(getApplicationContext(), "Boom  You Lost", Toast.LENGTH_LONG).show();
                            bothalive = false;
                        }else{
                            Toast.makeText(getApplicationContext(), "...puh", Toast.LENGTH_LONG).show();
                        }
                    }
                }else{
                    String result;
                    if(won){
                        result = "Victory !!";
                    }else{

                        result = "Loss !!";

                    }
                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
                }


                database.updateCharacter(me);
            } catch (Exception e) {
                Log.e("generate", "level bla "+ e.getLocalizedMessage());
            }
        }

    }


    private Character generateRandomEnemy(Character me_) throws Exception{
        int probability = (int) (1+ Math.random()*99);
        int attribute = 0;
        String name = "Wrong";
        int victories = 0, losses = 0, level = 1, experience = 0;

        if( isBetween(probability, 0, leveldepended) ){
            attribute = me_.getAttribute() +(int) (1+Math.random()*6);
            victories = (int) (5+Math.random()*100);
            losses = (int) (1+Math.random()*20);
            name = "Big";
            level =  me_.getLevel() + (int) (Math.random() * (me_.getLevel()+15));

        }else if (isBetween(probability,leveldepended,leveldepended2) ){
            attribute = me_.getAttribute() - (int) ((Math.random()*me_.getAttribute())-1);
            victories = (int) (1+Math.random()*20);
            losses=(int) (1+Math.random()*100);
            name = "small";
            level =  me_.getLevel()-20  + (int) (Math.random() * (me_.getLevel()));
            if(level <= 0)level = 1;
            Log.v("generater and", String.valueOf(attribute)+" "+String.valueOf(losses)+" "+String.valueOf(victories));
        }else{
            throw new Exception("probability out of range");
        }

        return new Character(name+"guy", attribute, losses, victories, level, experience);
    }

    public static boolean isBetween(int x, int lower, int upper) {
        return lower <= x && x <= upper;
    }

}
