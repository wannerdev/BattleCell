package com.example.battlecell;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public final class Data extends SQLiteOpenHelper {
	// Database Version
    private static final int DATABASE_VERSION = 1;
    // Database Name
    private static final String DATABASE_NAME = "DB";
    // list table name
    private static final String TABLE_CHARACTER = "character";

    // list Table Columns names
    private static final String GUY_ID = "id";
    private static final String GUY_NAME = "name";
    private static final String GUY_ATTRIBUTE1 = "attribute1";
    private static final String GUY_VICTORIES = "victories";
    private static final String GUY_LOSSES = "losses";
    private static final String GUY_LEVEL = "level";
    private static final String GUY_EXPERIENCE = "experience";
    private static final String[] COLUMNS = {GUY_ID, GUY_NAME, GUY_ATTRIBUTE1, GUY_VICTORIES, GUY_LOSSES, GUY_LEVEL,GUY_EXPERIENCE};

    //Singleton pattern
    private static Data database;
    
	private Data(Context context) {
		super(context, DATABASE_NAME, null,  DATABASE_VERSION);
		
	}
	public static Data getInstance(Context ctx) {
        /** Singleton
         */
        if (database == null) {
        	database = new Data(ctx.getApplicationContext());
        }
        return database;
    }
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		// SQL statement to create Character table
        String CREATE_CHARACTER_TABLE = "CREATE TABLE character ( " +
                "id INTEGER PRIMARY KEY , " + 
                "name TEXT, " +
                "attribute1 INTEGER," +
                "victories INTEGER," +
                "losses INTEGER," +
                "level INTEGER," +
                "experience REAL)";
 
        // create list table
        db.execSQL(CREATE_CHARACTER_TABLE);	

	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	    // Drop older character table if existed
        db.execSQL("DROP TABLE IF EXISTS Character");
 
        // create fresh character table
        this.onCreate(db);
	}
	
	
	public void addCharacter(Character guy){
		//for logging
		if(guy != null){
			Log.v("addCharacter", guy.toString()); 
		
			// 1. get reference to writable DB
			SQLiteDatabase db = this.getWritableDatabase();
			
			// 2. create ContentValues to add key "column"/value
			ContentValues values = new ContentValues();
			values.put(GUY_ID, guy.getId()); // get id
			values.put(GUY_NAME, guy.getName()); // get name 
			values.put(GUY_ATTRIBUTE1, guy.getAttribute());
			values.put(GUY_VICTORIES, guy.getVictories());
			values.put(GUY_LOSSES, guy.getLosses());
			values.put(GUY_LEVEL, guy.getLevel());
			values.put(GUY_EXPERIENCE, guy.getExperience());
			
			//GUY_ID,GUY_NAME, GUY_ATTRIBUTE1, GUY_VICTORIES, GUY_LOSSES
			// 3. insert
			//ALERRRt
			db.insert(TABLE_CHARACTER, // table
			        null, //nullColumnHack
			        values); // key/value -> keys = column names/ values = column values
			
			// 4. close
			db.close();
		}else{
			Log.e("addCharacter", "guy null");
		}
	}


 
    public Character getCharacter(int id){
 
        // 1. get reference to readable DB
        SQLiteDatabase db = this.getReadableDatabase();
 
        // 2. build query
        Cursor cursor = 
                db.query(TABLE_CHARACTER, // a. table
                COLUMNS, // b. column names
                " id = ?", // c. selections 
                new String[] { String.valueOf(id) }, // d. selections args
                null, // e. group by
                null, // f. having
                null, // g. order by
                null); // h. limit
 
        // 3. if we got results get the first one
        Character guy = null;
    //    Log.v("getCharacter", String.valueOf(cursor.moveToFirst()));
        if (cursor.moveToFirst() ){
            
            Log.v("getCharacter", String.valueOf(cursor.getColumnCount()) );
            if(cursor.getColumnCount() == 7){ //before 6
            	// 4. build character object
            	
            	//Log.v("getCharacter","all: " +String.valueOf((GUY_NAME )));
            	guy  = new Character(cursor.getString(cursor.getColumnIndexOrThrow(GUY_NAME)),
            					     cursor.getInt(cursor.getColumnIndex(GUY_ATTRIBUTE1)),
            						 cursor.getInt(cursor.getColumnIndex(GUY_LOSSES)),
            						 cursor.getInt(cursor.getColumnIndex(GUY_VICTORIES)),
            						 cursor.getInt(cursor.getColumnIndex(GUY_LEVEL) ),
            						 cursor.getInt(cursor.getColumnIndex(GUY_EXPERIENCE) ) );
            	//Log.d("getCharacter("+id+")", guy.toString());
            }
        }       
     // 3. close
        db.close();
 
        // 5. return guy
        return guy;
    }
 /*
  * Not needed atm
    // Get All Characters
    public List<Character> getAllCharacters() {
        List<Character> list = new LinkedList<Character>();
 
        // 1. build the query
        String query = "SELECT  * FROM " + TABLE_CHARACTER;
 
        // 2. get reference to writable DB
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
 
        // 3. go over each row, build book and add it to list
        Character guy = null;
        if (cursor.moveToFirst()) {
            do {
                guy = new Character();
                guy.setId(Integer.parseInt(cursor.getString(0)));
                guy.setTitle(cursor.getString(1));
                guy.setAuthor(cursor.getString(2));
 
                // Add book to s
                list.add(book);
            } while (cursor.moveToNext());
        }
 
        Log.d("getAlllist()", list.toString());
 
        return list;
    }
 */
     // Updating single Character
    public int updateCharacter(Character guy) {
 
        // 1. get reference to writable DB
        SQLiteDatabase db = this.getWritableDatabase();
 
        // 2. create ContentValues to add key "column"/value
		ContentValues values = new ContentValues();
		values.put(GUY_NAME, guy.getName()); // get name 
		values.put(GUY_ID, guy.getId()); // get aid
		values.put(GUY_ATTRIBUTE1, guy.getAttribute());
		values.put(GUY_VICTORIES, guy.getVictories());
		values.put(GUY_LOSSES, guy.getLosses());
		values.put(GUY_LEVEL, guy.getLevel() );
		values.put(GUY_EXPERIENCE, guy.getExperience() );
        // 3. updating row
        int i = db.update(TABLE_CHARACTER, //table
                values, // column/value
                GUY_ID+" = ?", // selections
                new String[] { String.valueOf(guy.getId()) }); //selection arguments
 
        // 4. close
        db.close();
 
        return i;
 
    }
 
    // Deleting single Character
    public void deleteCharacter(Character guy) {
 
        // 1. get reference to writable DB
        SQLiteDatabase db = this.getWritableDatabase();
 
        // 2. delete
        db.delete(TABLE_CHARACTER,
                GUY_ID+" = ?",
                new String[] { String.valueOf(guy.getId()) });
 
        // 3. close
        db.close();
 
        Log.d("deleteCharacter", guy.toString());
 
    }
}
