package com.example.battlecell;

import android.annotation.SuppressLint;
import android.graphics.Canvas;
import android.util.Log;

public class BattleLoop extends Thread {
	private BattleView theView;
	private Game2View game;
	private boolean isRunning = false;
	
	
	public BattleLoop(Object theView) {
        if(theView instanceof BattleView){
        	this.theView = (BattleView) theView;
        }else if(theView instanceof Game2View){
        	game = (Game2View) theView;
        }else{
        	Log.i("Battleoop", "wrong object");
        }
    }



	public void setRunning(boolean isRunning) {
		this.isRunning = isRunning;
	}
	
	@SuppressLint("WrongCall")
	@Override
    public void run() {
        while (isRunning) {
            Canvas theCanvas = null;
            //Game 1 or battleview
            if( theView != null){
	            try {
	                theCanvas = theView.getHolder().lockCanvas();
	                synchronized (theView.getHolder()) {
	                		theView.onDraw(theCanvas);
	                }
	            } finally {
	                if (theCanvas != null) {
	                    theView.getHolder().unlockCanvasAndPost(theCanvas);
	                }
	            }
	            //Game 2
           }else if(game != null){
        	   try {
	                theCanvas = game.getHolder().lockCanvas();
	                synchronized (game.getHolder()) {
	                		game.onDraw(theCanvas);
	                }
	            } finally {
	                if (theCanvas != null) {
	                    game.getHolder().unlockCanvasAndPost(theCanvas);
	                }
	            }
           }
        }
    }
}
