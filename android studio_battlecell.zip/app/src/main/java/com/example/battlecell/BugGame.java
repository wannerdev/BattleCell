package com.example.battlecell;

public class BugGame {
	//Todo
	public void route(){
		//export route here
	}
	
	public void directions(){
		//export directions here
	}

}
